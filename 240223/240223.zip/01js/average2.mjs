let arr = [87, 70, 100];

let average = 0;

for (let i = 0; i < arr.length; i++) {
  average += arr[i];
}

average /= arr.length;

console.log(average);

// 빠르고 간편하게 결과값 도출!!

const testFnc = () => {
  let a = 12 + 13;
};
