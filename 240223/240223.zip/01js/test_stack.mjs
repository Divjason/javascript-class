import { Stack } from "./Stack.mjs";

let stack = new Stack();

console.log("==== 첫 번째 출력 ====");
stack.push(1);
stack.push(2);
stack.push(3);
stack.push(4);
console.log(stack);
